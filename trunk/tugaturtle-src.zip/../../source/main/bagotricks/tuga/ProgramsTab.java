package bagotricks.tuga;

import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;

public class ProgramsTab {

	public List buttons = new ArrayList();

	public String group;

	public JList listComponent;

	public DefaultListModel listModel;

	public JPanel panel;

}
