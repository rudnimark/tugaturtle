100.times do
turn 60 * (rand - 0.5)
walk 10
end
