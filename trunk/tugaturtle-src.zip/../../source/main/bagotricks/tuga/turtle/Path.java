package bagotricks.tuga.turtle;

import java.awt.Color;
import java.awt.geom.GeneralPath;

public class Path {

	public GeneralPath awtPath = new GeneralPath();

	public Color color = Color.BLACK;

	public double width = 4.5;

	public Path() {
		awtPath.moveTo(0, 0);
	}

}
