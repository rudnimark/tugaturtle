40.times do
walk 700
turn 143
end
