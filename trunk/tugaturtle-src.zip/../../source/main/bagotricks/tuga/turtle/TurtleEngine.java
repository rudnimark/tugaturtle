package bagotricks.tuga.turtle;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.GeneralPath;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jruby.Ruby;
import org.jruby.RubyModule;
import org.jruby.exceptions.RaiseException;
import org.jruby.runtime.Arity;
import org.jruby.runtime.builtin.IRubyObject;
import org.jruby.runtime.callback.Callback;

import bagotricks.tuga.Engine;
import bagotricks.tuga.RunListener;
import bagotricks.tuga.StopException;

public class TurtleEngine implements Engine {

	private static final Pattern RUBY_FRAME_PATTERN = Pattern
			.compile("([^:]*):(\\d*)(?::((?:in `([^']*)')|.*))?");

	public Drawing drawing = new Drawing();

	private final Callback jump = new Callback() {

		public IRubyObject execute(IRubyObject recv, IRubyObject[] args) {
			double distance = args[0].convertToFloat().getDoubleValue();
			move(distance, false);
			return null;
		}

		public Arity getArity() {
			return Arity.singleArgument();
		}

	};

	public RunListener listener;

	public boolean paused;

	private final Callback pen = new Callback() {

		public IRubyObject execute(IRubyObject recv, IRubyObject[] args) {
			turtle.penDown = args[0].isTrue();
			return null;
		}

		public Arity getArity() {
			return Arity.singleArgument();
		}

	};

	private boolean stopNext;

	private final Callback turn = new Callback() {

		public IRubyObject execute(IRubyObject recv, IRubyObject[] args) {
			double angle = args[0].convertToFloat().getDoubleValue();
			angle += turtle.angle;
			// double turns = angle / 360;
			// turns = turns < 0 ? Math.
			// TODO Finish normalizing angle.
			turtle.angle = angle;
			onStep();
			return null;
		}

		public Arity getArity() {
			return Arity.singleArgument();
		}

	};

	public Turtle turtle = new Turtle();

	private final Callback walk = new Callback() {

		public IRubyObject execute(IRubyObject recv, IRubyObject[] args) {
			double distance = args[0].convertToFloat().getDoubleValue();
			move(distance, turtle.penDown);
			return null;
		}

		public Arity getArity() {
			return Arity.singleArgument();
		}

	};

	public TurtleEngine() {
		// Get things preloaded.
		new Thread() {
			public void run() {
				Ruby.getDefaultInstance().evalScript("");
			}
		}.start();
	}

	private RuntimeException buildException(RaiseException e) {
		String message = e.getMessage();
		int lineNumber = -1;
		StringBuffer buffer = new StringBuffer();
		buffer.append("\n\nStack trace:\n");
		IRubyObject backtrace = e.getException().backtrace();
		for (Iterator b = backtrace.convertToArray().iterator(); b.hasNext();) {
			String rubyFrame = (String)b.next();
			buffer.append(rubyFrame);
			buffer.append("\n");
			Matcher matcher = RUBY_FRAME_PATTERN.matcher(rubyFrame);
			if (!matcher.matches()) {
				throw new RuntimeException("unparsed ruby stack frame: "
						+ rubyFrame);
			}
			// TODO Check that it's from the right file.
			if (lineNumber == -1) {
				lineNumber = Integer.parseInt(matcher.group(2));
			}
		}
		if (lineNumber == -1) {
			Matcher matcher = RUBY_FRAME_PATTERN.matcher(e.getMessage());
			if (matcher.matches()) {
				lineNumber = Integer.parseInt(matcher.group(2));
			}
			message = matcher.group(3).trim();
			buffer.setLength(0);
		}
		RuntimeException exception = new RuntimeException("Error: "
				+ message
				+ (lineNumber >= 1 ? " on line " + lineNumber : "")
				+ buffer.toString(), e);
		return exception;
	}

	public void execute(String name, String script) {
		reset();
		onStep();
		Ruby ruby = Ruby.getDefaultInstance();
		// ruby.setSafeLevel(4);
		initCommands(ruby);
		try {
			ruby.eval(ruby.parse(script, name));
		} catch (RaiseException e) {
			if (e.getCause() != null) {
				Throwable cause = e;
				while (cause.getCause() != null) {
					cause = cause.getCause();
				}
				if (cause instanceof StopException) {
					// This was triggered on purpose. Expose it.
					throw (StopException)cause;
				}
			}
			System.err.println(e.getException().backtrace());
			System.err.println(e.getMessage());
			e.printStackTrace();
			throw buildException(e);
		} finally {
			paused = false;
			stopNext = false;
		}
	}

	private void initCommands(Ruby ruby) {
		RubyModule object = ruby.getObject();
		ruby.evalScript("def around() 180 end");
		ruby.evalScript("def down() true end");
		ruby.evalScript("def left() 90 end");
		ruby.evalScript("def right() -90 end");
		ruby.evalScript("def up() false end");
		object.defineMethod("jump", jump);
		object.defineMethod("pen", pen);
		object.defineMethod("turn", turn);
		object.defineMethod("walk", walk);
	}

	private void move(double distance, boolean penDown) {
		turtle.x += distance * Math.cos(Math.toRadians(turtle.angle));
		turtle.y += distance * Math.sin(Math.toRadians(turtle.angle));
		if (penDown) {
			drawing.lastPath().awtPath.lineTo((float)turtle.x, (float)turtle.y);
		} else {
			drawing.lastPath().awtPath.moveTo((float)turtle.x, (float)turtle.y);
		}
		onStep();
	}

	private void onStep() {
		synchronized (this) {
			if (paused) {
				try {
					wait();
				} catch (InterruptedException e) {
					// Fine by me.
				}
			}
			if (stopNext) {
				stopNext = false;
				throw new StopException();
			}
		}
		if (listener != null) {
			listener.onStep();
		}
	}

	public void paintCanvas(Component component, Graphics graphics) {
		Graphics2D g = (Graphics2D)graphics.create();
		try {
			int width = component.getWidth();
			int height = component.getHeight();
			g.setRenderingHint(
					RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			g.setColor(component.getBackground());
			g.fillRect(0, 0, width, height);
			g.translate(0.5 * width, 0.5 * height);
			double base = Math.min(width, height);
			g.scale(base / 1850, base / -1850);
			for (Iterator p = drawing.paths.iterator(); p.hasNext();) {
				Path path = (Path)p.next();
				g.setColor(path.color);
				g.setStroke(new BasicStroke(
						(float)path.width,
						BasicStroke.CAP_ROUND,
						BasicStroke.JOIN_ROUND));
				g.draw(path.awtPath);
			}
			paintTurtle(g);
		} finally {
			g.dispose();
		}
	}

	private void paintTurtle(Graphics2D g) {
		g = (Graphics2D)g.create();
		try {
			g.setColor(new Color(0, 128, 0));
			g.setStroke(new BasicStroke(9));
			g.translate(turtle.x, turtle.y);
			g.rotate(Math.toRadians(turtle.angle));
			g.translate(8, 0); // The turtle is a bit offset.
			GeneralPath path = new GeneralPath();
			path.moveTo(-20, -15);
			path.lineTo(-5, -15);
			path.lineTo(20, 0);
			path.lineTo(-5, 15);
			path.lineTo(-20, 15);
			path.closePath();
			g.draw(path);
		} finally {
			g.dispose();
		}
	}

	public void reset() {
		turtle.reset();
		drawing.reset();
	}

	public void setListener(RunListener listener) {
		this.listener = listener;
	}

	/**
	 * Stops the next thread that calls onStep.
	 */
	public void stop() {
		synchronized (this) {
			stopNext = true;
			paused = false;
			notify();
		}
	}

	public synchronized boolean togglePause() {
		if (paused) {
			paused = false;
			notify();
		} else {
			paused = true;
		}
		return paused;
	}

}
