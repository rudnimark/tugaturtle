package bagotricks.tuga;

public class StopException extends RuntimeException {

	/**
	 * Generated to stop Eclipse warnings, but I really don't care about
	 * serialization.
	 */
	private static final long serialVersionUID = 6603548796322268935L;

	// Nothing special needed.

}
