package bagotricks.tuga.turtle;

public class Turtle {

	public double angle;

	public boolean penDown;

	public double x;

	public double y;

	public Turtle() {
		reset();
	}

	public void reset() {
		angle = 90;
		penDown = true;
		x = 0;
		y = 0;
	}

}
