package bagotricks.tuga;

public interface RunListener {

	void onStep();

}
