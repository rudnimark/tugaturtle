package bagotricks.tuga;

public class ProgramGroup {

	public static final String EXAMPLES = "EXAMPLES";

	public static final String MY_PROGRAMS = "MY_PROGRAMS";

	public static final String TRASH = "TRASH";

}
