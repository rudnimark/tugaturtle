def square size
4.times do
walk size
turn right
end
end

square 700
