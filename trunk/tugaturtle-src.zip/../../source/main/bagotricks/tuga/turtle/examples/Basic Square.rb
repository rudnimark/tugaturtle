walk 400
turn right
walk 400
turn right
walk 400
turn right
walk 400
turn right

# Could we use 4.times instead?
