3.times do
walk 100
jump 100
end
walk 100
