package bagotricks.tuga;

public interface RenameListener {

	void renameTo(String name);

}
